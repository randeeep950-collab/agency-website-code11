Singh Designs 3D site

Upload this whole folder to Netlify (drag and drop), or test locally:
  python -m http.server 8765
  open http://localhost:8765/index.html
(Opening the files by double-click will not work: the 3D scripts need http.)
