(function(){var cart=[],box=document.getElementById('cart'),$=function(i){return document.getElementById(i)};
try{cart=JSON.parse(localStorage.getItem('sd_cart')||'[]')}catch(e){}
function save(){try{localStorage.setItem('sd_cart',JSON.stringify(cart))}catch(e){}}
function draw(){$('cc').textContent=cart.length;var t=0,h='';cart.forEach(function(c,i){t+=c.p;h+='<div class="ln"><span>'+c.n+'<small>'+c.l+'</small></span><button type="button" data-i="'+i+'" aria-label="Remove">×</button></div>'});
$('ci').innerHTML=h||'<p>Your cart is empty. Add a service to start.</p>';$('ct').textContent=cart.length?'Starting total: ₹'+t.toLocaleString('en-IN')+' (final price confirmed on WhatsApp)':'';
var m='Hi Singh Designs, I want to order:\n'+cart.map(function(c){return '- '+c.n+' ('+c.l+')'}).join('\n')+'\nStarting total: ₹'+t.toLocaleString('en-IN');
$('cs').href=cart.length?'https://wa.me/917340989151?text='+encodeURIComponent(m):'https://wa.me/917340989151'}
document.addEventListener('click',function(e){var b=e.target.closest('.pk .gold');if(b){var k=b.parentNode.dataset;cart.push({n:k.n,p:+k.p,l:k.l});save();draw();b.textContent='Added ✓';setTimeout(function(){b.textContent='Add to cart'},1200)}
var r=e.target.closest('#ci button');if(r){cart.splice(+r.dataset.i,1);save();draw()}});
$('cb').onclick=function(){box.classList.toggle('open')};$('cx').onclick=function(){box.classList.remove('open')};draw();
var s=$('search');if(s){var pills=document.querySelectorAll('.pill'),f='all';
function run(){var v=s.value.toLowerCase().trim(),n=0;document.querySelectorAll('.pk').forEach(function(c){var g=c.parentNode.dataset.g,ok=(f==='all'||f===g)&&(!v||c.textContent.toLowerCase().indexOf(v)>-1||g.indexOf(v)>-1);c.style.display=ok?'':'none';if(ok)n++});
document.querySelectorAll('.gh').forEach(function(h){var vis=h.nextElementSibling.querySelectorAll('.pk:not([style*="none"])').length;h.style.display=h.nextElementSibling.style.display=vis?'':'none'});$('none').hidden=n>0}
s.oninput=run;pills.forEach(function(p){p.onclick=function(){pills.forEach(function(x){x.classList.remove('on')});p.classList.add('on');f=p.dataset.f;run()}});
if(location.hash==='#search')s.focus()}})();
