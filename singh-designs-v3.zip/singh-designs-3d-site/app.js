import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
const home=document.body.dataset.mode==='home',reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,mobile=innerWidth<700;
let lenis=null;try{if(window.Lenis&&!reduce)lenis=new Lenis({lerp:.08})}catch(e){}
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('in')),{threshold:.15});
document.querySelectorAll('.rv').forEach(el=>io.observe(el));
const mb=document.getElementById('mb'),nav=document.querySelector('nav');mb&&mb.addEventListener('click',()=>nav.classList.toggle('open'));
const canvas=document.getElementById('gl');
try{
const r=new THREE.WebGLRenderer({canvas,antialias:!mobile});r.setPixelRatio(Math.min(devicePixelRatio,2));
r.toneMapping=THREE.ACESFilmicToneMapping;r.toneMappingExposure=1.1;r.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x060d20);scene.fog=new THREE.FogExp2(0x060d20,.045);
scene.environment=new THREE.PMREMGenerator(r).fromScene(new RoomEnvironment(),.04).texture;
const cam=new THREE.PerspectiveCamera(45,1,.1,100);
const key=new THREE.DirectionalLight(0xf3d98b,2.2);key.position.set(4,5,4);scene.add(key);
const rim=new THREE.PointLight(0x2f5bff,40,20);rim.position.set(-4,-2,-3);scene.add(rim);
const gold=new THREE.MeshStandardMaterial({color:0xd4af37,metalness:1,roughness:.22,flatShading:false});
const navyM=new THREE.MeshStandardMaterial({color:0x13244f,metalness:.85,roughness:.3});
const G={knot:()=>new THREE.TorusKnotGeometry(1,.32,mobile?160:260,32,2,3),ico:()=>new THREE.IcosahedronGeometry(1.3,1),octa:()=>new THREE.OctahedronGeometry(1.4),torus:()=>new THREE.TorusGeometry(1.1,.4,32,100),dodeca:()=>new THREE.DodecahedronGeometry(1.3),box:()=>new THREE.BoxGeometry(1.7,1.7,1.7),cone:()=>new THREE.ConeGeometry(1.2,2.2,6)};
const hero=new THREE.Mesh((G[document.body.dataset.shape]||G.knot)(),gold);scene.add(hero);
const rings=[1.9,2.5,3.2].map((rd,i)=>{const m=new THREE.Mesh(new THREE.TorusGeometry(rd,.012+i*.004,12,160),i===1?navyM:gold);m.rotation.set(Math.PI/2+i*.5,i*.7,0);hero.add(m);return m});
const tiles=new THREE.InstancedMesh(new THREE.BoxGeometry(.35,.35,.35),navyM,46),d=new THREE.Object3D();
for(let i=0;i<46;i++){const a=i*.62,rad=3.6+(i%5)*.35;d.position.set(Math.cos(a)*rad,(i/46-.5)*8,Math.sin(a)*rad-1);d.rotation.set(a,a*.5,0);d.updateMatrix();tiles.setMatrixAt(i,d.matrix)}
if(home)scene.add(tiles);
const N=mobile?600:1400,pos=new Float32Array(N*3).map(()=>(Math.random()-.5)*26);
const dust=new THREE.Points(new THREE.BufferGeometry().setAttribute('position',new THREE.BufferAttribute(pos,3)),new THREE.PointsMaterial({color:0xf3d98b,size:.035,transparent:true,opacity:.7,depthWrite:false}));scene.add(dust);
const path=[[0,0,7.5],[3.6,1.2,5],[-3.4,-.8,4.2],[0,3,5.5],[0,0,3.2]],ease=t=>t*t*(3-2*t);
const samp=t=>{const s=Math.min(t,.9999)*(path.length-1),i=Math.floor(s),f=ease(s-i);return path[i].map((v,j)=>v+(path[i+1][j]-v)*f)};
let prog=0,tgt=0,mx=0,my=0,tx=0,ty=0;const bar=document.getElementById('bar');
const rs=()=>{const m=document.documentElement.scrollHeight-innerHeight;tgt=m>0?Math.min(Math.max(scrollY/m,0),1):0;bar.style.width=tgt*100+'%'};
addEventListener('scroll',rs,{passive:true});rs();
addEventListener('pointermove',e=>{tx=e.clientX/innerWidth-.5;ty=e.clientY/innerHeight-.5},{passive:true});
const size=()=>{r.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.fov=innerWidth<700?60:45;cam.updateProjectionMatrix()};addEventListener('resize',size);size();
const clock=new THREE.Clock();let run=true;document.addEventListener('visibilitychange',()=>{run=!document.hidden;clock.getDelta()});
const tick=t=>{requestAnimationFrame(tick);if(lenis)lenis.raf(t);if(!run)return;
const dt=Math.min(clock.getDelta(),.1),k=1-Math.pow(1-.07,dt*60);prog+=(tgt-prog)*k;mx+=(tx-mx)*k;my+=(ty-my)*k;
const sp=reduce?0:dt;
if(home){const p=samp(prog);cam.position.set(p[0]+mx*1.2,p[1]-my*.8,p[2]);hero.rotation.x=prog*Math.PI*2;hero.scale.setScalar(1+Math.sin(prog*Math.PI)*.25);tiles.rotation.y=prog*Math.PI*1.5;tiles.position.y=prog*2}
else{cam.position.set(mx*.8,-my*.5,8);hero.position.set(mobile?0:2.6,mobile?2.4:0,0);hero.rotation.x=prog*Math.PI;hero.scale.setScalar(mobile?.7:1)}
cam.lookAt(0,0,0);hero.rotation.y+=sp*.25+(home?0:0);
rings.forEach((m,i)=>m.rotation.z+=sp*(.1+i*.06)*(i%2?-1:1));dust.rotation.y+=sp*.02;r.render(scene,cam)};
requestAnimationFrame(tick);
}catch(e){canvas.style.display='none';document.body.style.background='radial-gradient(circle at 50% 20%,#13244f,#060d20)';if(lenis){const f=t=>{lenis.raf(t);requestAnimationFrame(f)};requestAnimationFrame(f)}}
